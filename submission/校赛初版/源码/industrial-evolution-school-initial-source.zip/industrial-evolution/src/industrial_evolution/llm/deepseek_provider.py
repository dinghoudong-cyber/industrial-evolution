from __future__ import annotations

from .openai_provider import LLMProviderError, OpenAICompatibleProvider

__all__ = ["DeepSeekProvider", "LLMProviderError"]


class DeepSeekProvider(OpenAICompatibleProvider):
    """DeepSeek 官方端点的便捷入口。

    等价于 ``provider=deepseek`` 的通用 OpenAI 兼容客户端，保留该类名是为了兼容既有
    调用点与测试；新增端点请使用 ``llm.factory.build_provider`` 统一构造。
    """
