# 工业模型自进化框架

面向工业漂移数据流的可复现持续学习框架。系统自动完成：

```text
监测 → 诊断 → 更新决策 → 回放训练 → 候选评估 → 上线或拒绝 → 回滚
```

> 普通用户请先阅读：[用户功能说明](docs/用户功能说明.md)。其中包含功能解释、双击运行、CSV接入、结果查看、配置参数和故障排查。也可以直接双击 `docs\用户功能说明.html` 查看排版版。
>
> 四轮实测数据、性能热点、正确性审计和逐项优化过程见：[四轮测试与优化记录](docs/三轮测试优化记录.md)。
>
> 每个文件夹、子文件夹和主要文件的职责见：[项目文件夹详细说明](docs/项目文件夹说明.md)。
>
> 想一次看清"系统能做什么、每个机制怎么实现的、代码落在哪个文件夹"：**[功能实现报告](docs/功能实现报告.md)**（排版版 `docs\功能实现报告.html`）。
>
> CPU时间、峰值内存、模型大小、标签和Token估算见：[算力与Token需求说明](docs/算力与Token需求说明.md)。
>
> Ruff静态检查和Windows Docker Desktop安装、构建说明见：[Ruff与Docker使用说明](docs/Ruff与Docker使用说明.md)。
>
> 官方 CPU A/B/C 嵌套 JSONL 包的本地离线验证与预测参考协议见：[官方 CPU 包本地验证](docs/官方CPU包本地验证.md)；不代表已适配正式评测接口。
>
> 参赛镜像、源码、实验记录、报告、演示和来源声明的准备清单见：[参赛提交材料与证据清单](docs/提交材料与证据清单.md)。
>
> 规模、漂移强度、漂移时机与特征维度的 10 场景对照实验见：[扩展性验证报告](docs/扩展性验证报告.md)；平台模型服务、11/9 记录规范与批次协议的阶段边界见：[企业赛平台对接与规范核对清单](docs/企业赛平台对接与规范核对清单.md)。

## 主要能力

- PSI、KS、Wasserstein及缺失/无穷值质量监测；
- 滚动性能下降、Page-Hinkley和多类别标签分布监测；
- 首次标签访问计费、冷却期和训练/标注/Token预算；
- 训练回放与不可训练历史守护集严格隔离；
- Champion-Challenger安全上线与历史守护集；
- 模型注册、版本保存、自动回滚和异常兜底；
- JSONL事件、CSV指标、JSON汇总，以及可选SwanLab三层镜像（曲线/判断链/可复算产物）；
- 逐批次「上线/不上线」判断落盘 `decisions.jsonl`，可配置主指标（macro_f1 / negative_rmse）与同口径 `vs_official_baseline`；
- 标签默认只记账不阻断（赛题口径：评测总能拿到标签）、`min_updates` 对「至少三次迭代」做显式校验；
- 合成漂移演示、CSV顺序流和Docker运行入口；
- 可选策略大模型：正式 Harness 按赛方要求使用 Qwen3.8 27B/4B；DeepSeek 配置仅开发调试，具备规则回退；
- 统一容器入口与离线环境自检（依赖、端点、输出目录）。

## 策略模型接入

策略模型默认关闭（`tuned.yaml`、`static.yaml` 不联网，Token 恒为 0）。需要大模型参与决策时，按评测
环境选一种 provider，两种情况复用同一段受控决策代码：

| provider | 适用场景 | 端点约束 |
|---|---|---|
| `deepseek` | 仅开发调试，不用于正式 Harness | 只允许 `https://api.deepseek.com` |
| `openai_compatible` | 本地 vLLM / sglang 承载赛方允许的 Qwen3.8 27B 或 4B | 允许本机、内网 http；公网必须 https |

Qwen3.8 的实际模型路径与服务端 ID 以赛方/模型服务提供的清单为准，不猜测别名。启动本地服务的命令模板：

```powershell
$modelPath = "D:\models\<Qwen3.8-27B-or-4B>"
$modelId = "<实际-served-model-ID>"
python -m vllm.entrypoints.openai.api_server `
  --model $modelPath --served-model-name $modelId `
  --host 127.0.0.1 --port 8000
```

用 `configs/local-qwen.yaml` 验证接入（配置里 `api_key_required: false`，本地服务无需鉴权）：

```powershell
.\.venv\Scripts\python.exe -m industrial_evolution.cli env-check --config configs\local-qwen.yaml
.\.venv\Scripts\python.exe -m industrial_evolution.cli llm-smoke-test --config configs\local-qwen.yaml
.\.venv\Scripts\python.exe -m industrial_evolution.cli demo --config configs\local-qwen.yaml
```

不改 YAML 也能临时切端点，`demo`、`run-csv`、`llm-smoke-test` 都支持：

```powershell
--provider openai_compatible --base-url http://127.0.0.1:8000/v1 --model <实际-served-model-ID>
```

手头没有推理服务时，可以用 `tools\mock_llm_server.py` 起一个最小 OpenAI 兼容端点，把决策链路先跑通：

```powershell
.\.venv\Scripts\python.exe tools\mock_llm_server.py --port 8123
.\.venv\Scripts\python.exe -m industrial_evolution.cli llm-smoke-test `
  --config configs\local-qwen.yaml --base-url http://127.0.0.1:8123/v1
```

DeepSeek 官方端点仅用于开发调试：设置 `DEEPSEEK_API_KEY` 环境变量（不要写进 YAML、代码或文档），再运行
`llm-smoke-test --config configs\deepseek-dev.yaml`。该调用会计费，不得作为正式 Harness 模型。

接入的安全边界写在 `LLMConfig` 的校验里，配置写错会直接启动失败：`base_url` 不得带账号、查询串或片段；
公网地址必须 https；`api_key_env` 必须是大写且以 `API_KEY` / `TOKEN` 结尾，避免配置被改成读取任意
环境变量外发；可用 `allowed_hosts` 再收一层白名单。

运行时容错：端点不支持 `response_format`（部分 vLLM 版本）时自动降级为提示词约束并重试一次；端点不可用、
超时、低置信度或返回非法 JSON 时回退规则策略，闭环不中断，事件流里记录 `llm_fallback` 及原因。

正式 Harness 使用赛方建议的 Qwen3.8 27B 或 4B；若需进一步适配，可在 Qwen 基础上使用 PyTRiO 后训练。后训练模型 ID 与 PyTRiO API Key 按平台要求提交，API Key 只通过平台安全渠道提供，不写入源码、配置、实验日志或报告。正式评测保持赛方要求的网络边界；最终不使用 DeepSeek。

## 快速开始

### 已安装环境

直接双击：

```text
D:\industrial_evolution\运行演示.bat
```

或在PowerShell中运行：

```powershell
cd D:\industrial_evolution
.\.venv\Scripts\python.exe -m industrial_evolution.cli demo `
  --config configs\tuned.yaml
```

### 重新安装开发环境

```powershell
cd D:\industrial_evolution
D:\Python313\python.exe -m venv .venv
$env:PIP_CACHE_DIR = "D:\pip-cache"
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest
```

## 使用自己的CSV

CSV必须保持真实时间顺序，第一版只接受数值特征：

```powershell
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-csv `
  --csv D:\数据\train.csv `
  --target label `
  --initial-size 1000 `
  --window-size 200 `
  --drop-column timestamp
```

完整要求见[用户功能说明：如何接入自己的CSV](docs/用户功能说明.md#6-如何接入自己的-csv)。

## 官方数据包接入

数据包结构按「命令行参数 > 包内清单（manifest）> 常见命名推断」三级解析，任何一级都确定不了时
启动即报错，并列出找过哪些文件名、缺哪一列：

```powershell
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-official `
  --pack D:\官方数据包 --print-spec          # 先确认解析结果
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-official `
  --pack D:\官方数据包 --config configs\official.yaml
```

清单字段、命令行覆盖项、以及接入层会挡住的七类数据问题见
[官方数据包接入说明](docs/官方数据包接入说明.md)。标签延迟与官方评测脚本直连尚未支持，文档末尾有说明。

## 配置文件

| 文件 | 用途 |
|---|---|
| `configs/tuned.yaml` | 当前合成流的推荐演示配置，离线且Token为0 |
| `configs/default.yaml` | 较保守的通用起点，离线且Token为0 |
| `configs/static.yaml` | 禁止更新的静态对照组，离线且Token为0 |
| `configs/deepseek-dev.yaml` | DeepSeek开发验证配置，不用于正式离线评测 |
| `configs/local-qwen.yaml` | 本地 vLLM / sglang 承载 Qwen 的评测配置，OpenAI 兼容端点 |
| `configs/official.yaml` | 官方数据包运行的起点配置，参数需按官方指标重新校准 |
| `configs/cmapss.yaml` | C-MAPSS FD001~FD004 的 RUL 回归起点配置 |
| `configs/gas.yaml` | UCI Gas 批次漂移分类起点配置 |
| `configs/xjtu.yaml` | XJTU-SY 单轴承全寿命离线 RUL 回归起点配置 |

公开 A/B/C 包与 baseline 仅用于开发参考；正式数据由平台在测评时提供并负责评分。不得在本地推测隐藏数据或评分协议；本地参数校准结果与最终成绩以平台测评为准。

## 真实工业数据集（C-MAPSS / Gas / XJTU-SY）

项目附带三个真实数据集适配器：C-MAPSS 以每台 engine 的最大 cycle 构造 piecewise-linear RUL 标签，并按 engine 内时间顺序添加滑动均值、标准差和跨度趋势特征；Gas 解析 UCI 的 libsvm 文件，按 batch1→batch10 保留数据顺序；XJTU-SY 每次只处理一个指定轴承，将每个一分钟振动 CSV 聚合为两个通道的均值、标准差、RMS、峰峰值、偏度和峭度。XJTU-SY 不能把多个轴承拼成一个自然时间流。

```powershell
# C-MAPSS RUL 回归（默认 FD001，RUL 截断上限 130）
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-cmapss `
  --data-dir datasets\cmapss --fd FD001 --config configs\cmapss.yaml

# Gas 6 类气体分类（按 batch 顺序模拟传感器漂移）
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-gas `
  --data-dir datasets\gas --config configs\gas.yaml

# XJTU-SY 单轴承全寿命离线 RUL 回归（示例）
.\.venv\Scripts\python.exe -m industrial_evolution.cli run-xjtu `
  --data-dir "D:\桌面\XJTU-SY轴承数据集\Data" `
  --condition 40Hz10kN --bearing Bearing3_1 --config configs\xjtu.yaml
```

XJTU-SY 的 RUL 由“该轴承已知最后文件序号 − 当前文件序号”推导，单位分钟；这依赖整条寿命序列已完整取得，仅适用于**全寿命离线实验**，不代表真实在线阶段可以提前获得寿命终点或标签。命令要求明确指定一个工况和一个轴承，文件序号必须从 1 连续；每次只读取当前所需 CSV，不把 32,768 个采样点逐行作为样本。配置中的回归阈值只是起点，必须结合官方指标和同条件静态基线校准。此前 C-MAPSS 和 Gas 的注意事项仍适用：C-MAPSS 配置用负 RMSE（越接近 0 越好），Gas 原始类别可能在连续窗口集中；不能为改善数字而随机打乱时间流。三个适配器均实现统一的 `StreamSource` 协议，可进入同一个进化闭环，但“读取并跑通”不等于优于基线。

XJTU-SY 工程 smoke test 已按默认配置完整跑过 `40Hz10kN/Bearing3_1`（2,538 个样本、48 窗）：0 个窗口失败、Token 0；但负 RMSE 从初始 `-32.440995` 降至最终 `-2451.863314`，8 个候选全部被拒绝。因此这只是工程连通证据，现阶段预测效果明显不佳，**不能说模型已经有效或优于静态基线**。

## 配置文件

镜像内置统一入口 `run.sh`，评测方不需要关心内部 python 调用：

```bash
docker build -t industrial-evolution:0.1.0 .
docker run --rm -v "$PWD/out:/app/runs" industrial-evolution:0.1.0 check   # 环境自检
docker run --rm -v "$PWD/out:/app/runs" industrial-evolution:0.1.0 demo    # 合成流演示
docker run --rm -v "$PWD/out:/app/runs" \
  -e IE_CSV=/data/stream.csv -e IE_TARGET=label -e IE_INITIAL_SIZE=1000 \
  industrial-evolution:0.1.0 csv                                          # 正式数据流
```

国内网络下 Docker Hub 不可直连，需先拉镜像站再打标签，构建时可用 `--build-arg PIP_INDEX_URL=<国内源>` 换 pip 源（不改变 `requirements.lock` 的锁定版本）。完整步骤见 `docs\Ruff与Docker使用说明.md`。

| 变量 | 含义 |
|---|---|
| `IE_CONFIG` | 配置文件路径，默认 `/app/configs/tuned.yaml` |
| `IE_RUN_ROOT` | 输出根目录，默认 `/app/runs` |
| `IE_CSV`、`IE_TARGET`、`IE_INITIAL_SIZE`、`IE_WINDOW_SIZE` | `csv` 模式的数据文件与切窗参数 |
| `IE_SWANLAB` | 设为 `1` 开启 SwanLab 镜像记录 |
| `IE_SWANLAB_MODE` | `online` / `local` / `offline` / `disabled`，默认取配置文件 |
| `SWANLAB_API_KEY` | 云端记录密钥；只开记录不给密钥会自动降级为 `offline` |

`check` 会打印 Python 版本、`openai` / `swanlab` 是否可用、端点连通性、输出目录可写性；加 `--strict`
时自检不通过以非零码退出，可直接当容器健康检查用。`record` 是记录通道自检，会真写一条标量与一条
文本，确认看板通路可用。构建与运行说明见 `docs\Ruff与Docker使用说明.md`。

## SwanLab 记录

SwanLab 只做镜像，本地 `runs/<run_id>/` 才是主记录；上传失败不打断进化闭环。

```bash
python -m industrial_evolution swanlab-check --online   # 先确认通道能写
python -m industrial_evolution demo --swanlab --swanlab-mode online
```

记录分三层：**曲线**（每窗口得分/漂移/预算，`step` 为窗口序号，多轮可叠加对比）、
**判断链**（每窗口"观察→诊断→决策→预期→结果→判定"，被否定的假设同样保留）、
**产物**（`summary.json`、`metrics.csv`、`events.jsonl`、模型注册表 作为 run 文件上传，
第三方不接触本地目录也能复算）。无凭证时会自动降级为 `offline` 落盘并给出原因，
不会卡在交互登录上。完整用法见 `docs\SwanLab记录使用说明.md`。

## 运行产物

```text
runs\run-日期时间-编号\
├── events.jsonl       # 状态迁移、诊断、决策、训练、上线、回滚
├── metrics.csv        # 每个数据窗口的指标、动作和累计成本
├── summary.json       # 整次运行摘要
└── models\            # 模型版本和注册表
```

## 当前对照结果

固定随机种子`42`，在相同18个合成窗口上：

| 配置 | 平均平衡准确率 | 最后窗口 | 更新尝试 | 上线 | 异常 |
|---|---:|---:|---:|---:|---:|
| 静态基线 | 0.614526 | 0.538245 | 0 | 0 | 0 |
| 自进化（无泄漏守护集） | 0.676200 | 0.699060 | 6 | 4 | 0 |

修复后标签账本按“首次访问即计费”，标准18窗口运行记录4200个不同标签，而不是只记录训练子集。最后窗口是「先打分、后上线」，因此 `final_score` 记的是当时冠军（v003）的分数；该窗口之后上线的 v004 不会被任何窗口评分，摘要因此额外记录 `final_deployed_score`（v004 上线时在未参与训练的 holdout 上的得分）与 `final_deployed_guard_score`（历史守护集得分）。v004 的 holdout 得分为 0.660055，低于 v003 的全窗口 0.699060 —— 最后一次上线在这个窗口上并没有带来提升，这个结论如实留在摘要里，不做修饰。相同种子复跑后，关键指标、动作次数和模型版本一致。此结果只验证工程闭环，不代表官方隐藏测试成绩。

## 项目结构

```text
src/industrial_evolution/
├── data/           # 合成流、CSV流和官方数据包接入
├── monitoring/     # 特征、性能和标签漂移
├── memory/         # 历史回放缓冲区
├── models/         # 模型适配器和版本注册
├── policy/         # 规则门控与大模型混合策略
├── llm/            # 提供商协议、严格JSON结构、OpenAI兼容适配器与工厂
├── training/       # 候选训练
├── evaluation/     # Champion-Challenger评估
├── tracking/       # 本地记录和SwanLab镜像
├── orchestrator.py # 端到端状态机与LLM用量记录
└── cli.py          # demo、run-csv、run-official、llm-smoke-test和env-check命令
```

## 开发验证

```powershell
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m ruff check src tests
.\.venv\Scripts\python.exe -m ruff format --check src tests
```

Docker构建与Windows安装步骤见 `docs\Ruff与Docker使用说明.md`。镜像已完成首次实际构建与运行验证：
546 MB，构建 35 秒；`--network none --memory 1g --cpus 1 --read-only` 下 18 窗口全部完成、0 失败，
`final_score` 与宿主机运行逐位一致（0.69906，v004 上线，holdout 0.660055），`docker save` 产出 540 MB 离线包。

当前共114项测试通过，近期新增用例覆盖两类能力：策略模型侧的安全校验、无鉴权本地端点、
`response_format` 降级重试与 provider 工厂分派；记录侧的三层留痕（曲线数值化上报、判断链落盘与镜像、
镜像连续失败停用、close 顺序、无凭证自动降级），以及官方数据包的清单解析、命名推断、ID唯一性、
非数值列拦截和端到端跑通。

测试覆盖漂移检测、非有限值质量告警、预算与标签去重、训练/守护集隔离、策略冷却、候选评估、完整状态回滚、记录器降级、端到端运行、跨平台CLI编码和可复现基准，以及策略模型端点的安全校验、无鉴权本地端点、`response_format` 降级与工厂分派。

## 后续接入点（2026-11-12 更新）

已闭环：主指标可配置（`validation.score_metric`）、标签默认只记账不阻断（`budget.label_budget_mode`）、逐批次 `decisions.jsonl` 判断、`vs_official_baseline` 同口径比较、`min_updates` 校验、镜像构建与断网受限实测、扩展性验证（10 场景 × 2 组）。

仍待办，按优先级：

1. **打通官方 JSONL 包 → 闭环**：`run-official` 目前按 CSV 清单假设解析，官方 A/B/C 包是 `id/inputs/answer/meta` JSONL；`data/official_jsonl.py` 与 `official_runner.py` 能读真包但未接入 `EvolutionOrchestrator`。这是当前最大缺口。
2. **产出可被评测方加载的最终模型**：闭环产 sklearn `joblib`，官方协议要 `checkpoint.npz + training.json + history.jsonl`；补齐 B/C 官方格式轮次与 ≥3 次迭代证据。
3. **在线批次握手**：把 `decisions.jsonl` 的 `deploy/no_update` 判断接到「先判断、才取下一批」的阻塞式批次流。
4. **SwanLab 公开性整改**：项目当前已核实为非公开，需设为公开并完成匿名访问验收；见 `submission/校赛初版/实验记录/SwanLab记录公开性整改说明.md`。
5. **企业赛平台接入**：Qwen3.8 27B / 4B 服务、PyTRiO 后训练、代金券、API Key 安全提交与 11/9 记录规范核对，见 `docs/企业赛平台对接与规范核对清单.md`。校赛阶段一律不接入、不声明。
6. **技术创新加分**：策略层自改进（阈值/冷却自适应）、成本-增益帕累托、总墙钟与进程 RSS 的运行时采集。
