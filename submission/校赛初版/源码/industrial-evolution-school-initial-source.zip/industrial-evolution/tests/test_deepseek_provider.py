from __future__ import annotations

import json
from types import SimpleNamespace

import pytest

from industrial_evolution.config import LLMConfig
from industrial_evolution.domain import Action
from industrial_evolution.llm.deepseek_provider import DeepSeekProvider, LLMProviderError
from industrial_evolution.llm.provider import LLMDecisionRequest


class FakeCompletions:
    def __init__(self, content: str | None) -> None:
        self.content = content
        self.kwargs = None

    def create(self, **kwargs):
        self.kwargs = kwargs
        return SimpleNamespace(
            model="deepseek-flash",
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content=self.content),
                    finish_reason="stop",
                )
            ],
            usage=SimpleNamespace(
                prompt_tokens=123,
                completion_tokens=37,
                total_tokens=160,
                completion_tokens_details=SimpleNamespace(reasoning_tokens=7),
            ),
        )


class FakeClient:
    def __init__(self, content: str | None) -> None:
        self.completions = FakeCompletions(content)
        self.chat = SimpleNamespace(completions=self.completions)


def request() -> LLMDecisionRequest:
    return LLMDecisionRequest(
        window_index=8,
        drift_kind="mixed",
        feature_drift_score=2.5,
        top_features=("sensor_00", "sensor_01"),
        current_score=0.60,
        rolling_score=0.62,
        baseline_score=0.74,
        performance_drop=0.12,
        label_shift=0.15,
        remaining_updates=4,
        remaining_training_seconds=119.0,
        remaining_labels=3500,
        remaining_tokens=5000,
        requested_labels=140,
        rule_reason="持续漂移",
    )


def test_deepseek_provider_requests_json_and_records_usage():
    client = FakeClient(
        json.dumps(
            {
                "action": "retrain_with_replay",
                "confidence": 0.88,
                "reason": "性能持续下降，建议训练候选",
            },
            ensure_ascii=False,
        )
    )
    provider = DeepSeekProvider(LLMConfig(), client=client)

    result = provider.decide(request())

    assert result.action is Action.RETRAIN_WITH_REPLAY
    assert result.confidence == 0.88
    assert result.usage.input_tokens == 123
    assert result.usage.output_tokens == 37
    assert result.usage.reasoning_tokens == 7
    assert result.usage.total_tokens == 160
    assert client.completions.kwargs["model"] == "deepseek-flash"
    assert client.completions.kwargs["response_format"] == {"type": "json_object"}
    assert client.completions.kwargs["max_tokens"] == 160
    user_payload = client.completions.kwargs["messages"][1]["content"]
    assert "sensor_00" in user_payload
    assert "API" not in user_payload


def test_deepseek_provider_rejects_invalid_or_extra_json():
    invalid = FakeClient("not json")
    with pytest.raises(LLMProviderError, match="不是有效JSON") as invalid_error:
        DeepSeekProvider(LLMConfig(), client=invalid).decide(request())
    assert invalid_error.value.usage.total_tokens == 160
    assert invalid_error.value.model == "deepseek-flash"
    assert "finish_reason=stop" in str(invalid_error.value)

    extra = FakeClient('{"action":"no_update","confidence":0.8,"reason":"等待","command":"rm"}')
    with pytest.raises(LLMProviderError, match="不符合策略白名单"):
        DeepSeekProvider(LLMConfig(), client=extra).decide(request())


def test_deepseek_provider_reports_empty_content_without_exposing_it():
    client = FakeClient(None)

    with pytest.raises(LLMProviderError, match="响应正文为空") as caught:
        DeepSeekProvider(LLMConfig(), client=client).decide(request())

    assert caught.value.usage.total_tokens == 160
    assert caught.value.latency_seconds >= 0
    assert "total_tokens=160" in str(caught.value)


def test_missing_api_key_names_environment_variable_without_exposing_secret(monkeypatch):
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)
    provider = DeepSeekProvider(LLMConfig())

    with pytest.raises(LLMProviderError, match="DEEPSEEK_API_KEY 未设置"):
        provider.decide(request())


def test_llm_config_rejects_untrusted_endpoint_and_secret_name():
    with pytest.raises(ValueError):
        LLMConfig(base_url="http://127.0.0.1:8080")
    with pytest.raises(ValueError):
        LLMConfig(base_url="https://attacker.example")
    with pytest.raises(ValueError):
        LLMConfig(api_key_env="OTHER_SECRET")
